## Sim3DR
This is a simple 3D render, written by c++ and cython. 

### Build Sim3DR

```shell script
python3 setup.py build_ext --inplace
```